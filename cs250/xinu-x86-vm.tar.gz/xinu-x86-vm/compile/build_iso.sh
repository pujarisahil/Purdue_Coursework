cp ./xinu ./iso/boot
./iso_util/grub/bin/grub-mkrescue -o xinu.iso iso/
