/* -*- indent-tabs-mode; t; tab-width: 8; c-basic-offset: 8; -*- */

#ifndef __ERROR_H
#define __ERROR_H

#define BE_CANCELLED 1

#endif /* __ERROR_H */
