#include <stdio.h>
#include <stdlib.h>

#define MAXROWS 100
#define MAXCOLS 101

void printMatrix(int rows, int columns, double matrix[][MAXCOLS]);

/* Add helper functions and global variables here */

int main()
{
	/* Add your implementation here */

	return 0;
}

void printMatrix(int rows, int columns, double matrix[][MAXCOLS])
{
	/* Add your implementation here */

}
