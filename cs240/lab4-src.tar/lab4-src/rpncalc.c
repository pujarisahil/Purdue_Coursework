
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char ** argv)
{
}
