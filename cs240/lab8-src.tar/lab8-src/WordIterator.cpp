
#include <stdio.h>
#include <stdlib.h>
#include "WordIterator.h"

WordIterator::WordIterator()
{
}

bool
WordIterator::readFile(const char * fileName)
{
  return false;
}

const char * 
WordIterator::next()
{
  return NULL;
}

WordIterator::~WordIterator()
{

}

