
#include <string.h>
#include <stdio.h>

#include "TreeDictionary.h"

TreeDictionary::TreeDictionary()
{
}

// Add a record to the dictionary. Overwrite data if key
// already exists. It returns false if key already exists
bool 
TreeDictionary::addRecord( const char * key, int data) {
	return true;
}

int
TreeDictionary::numberOfEntries() {
  return _numberOfEntries;
}

// Find a key in the dictionary and return corresponding record.
bool 
TreeDictionary::findRecord( const char * key, int & data) {
	return false;
}

void 
TreeDictionary::printIndented(TreeNode * node, int level) {
}

void 
TreeDictionary::printIndented(){
}

void 
TreeDictionary::print(TreeNode *node) {
}

void TreeDictionary::print()
{
}

// Max depth in tree
void
TreeDictionary::computeDepthHelper(TreeNode * node, int depth, int & currentMaxDepth) {

  return;
}

int 
TreeDictionary::maxDepth() {
  return 0;
}


TreeDictionary::~TreeDictionary()
{
}

// Minimum key. The leftmost node
const char * 
TreeDictionary::minimumKey()
{
   return "";
}

// Maximum Key. The rightmost node
const char * 
TreeDictionary::maximumKey()
{
   return "";
}

void
TreeDictionary::collectKeys(TreeNode * node, const char **keys, int & nkeys)
{
}

const char ** 
TreeDictionary::keys( int & nkeys)
{
  return NULL;
}




