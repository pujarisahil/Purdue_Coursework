#include <stdio.h>

int add(int a, int b) {
	return a + b;
}

int main() {
	printf("2 + 2 = %d\n", add(2, 2));
}
